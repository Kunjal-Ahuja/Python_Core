"""
validator.py
--------------
Helper/validation functions used across the library system, such as
checking book availability before borrowing or validating a membership
type.
"""

VALID_MEMBERSHIP_TYPES = {"regular", "premium"}


def is_book_available(book):
    """Return True if the given Book can currently be borrowed."""
    return book is not None and book.is_available


def is_valid_membership_type(membership_type):
    """Return True if the given membership type is one of the recognized
    values ('regular' or 'premium')."""
    return isinstance(membership_type, str) and membership_type.lower() in VALID_MEMBERSHIP_TYPES


def is_valid_age(age):
    """Return True if age is a non-negative integer."""
    return isinstance(age, int) and age >= 0


def is_non_empty_string(value):
    """Return True if value is a non-empty (after stripping) string."""
    return isinstance(value, str) and value.strip() != ""
