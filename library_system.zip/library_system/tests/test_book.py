"""test_book.py - Validates book CRUD operations."""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data.datastore import datastore
from services import book_service


class BookServiceTestCase(unittest.TestCase):
    def setUp(self):
        datastore.reset()

    def test_add_book(self):
        book = book_service.add_book("B001", "Python Programming", "John Smith", "Programming")
        self.assertEqual(book.id, "B001")
        self.assertTrue(book.is_available)
        self.assertIn("B001", datastore.books)

    def test_add_duplicate_book_raises(self):
        book_service.add_book("B001", "Python Programming", "John Smith", "Programming")
        with self.assertRaises(ValueError):
            book_service.add_book("B001", "Another Title", "Another Author", "Fiction")

    def test_get_book(self):
        book_service.add_book("B001", "Python Programming", "John Smith", "Programming")
        book = book_service.get_book("B001")
        self.assertIsNotNone(book)
        self.assertEqual(book.title, "Python Programming")

    def test_get_all_books(self):
        book_service.add_book("B001", "Python Programming", "John Smith", "Programming")
        book_service.add_book("B002", "The Hobbit", "J.R.R. Tolkien", "Fantasy")
        books = book_service.get_all_books()
        self.assertEqual(len(books), 2)

    def test_update_availability(self):
        book_service.add_book("B001", "Python Programming", "John Smith", "Programming")
        updated = book_service.update_availability("B001", False)
        self.assertFalse(updated.is_available)

    def test_update_availability_nonexistent_book_raises(self):
        with self.assertRaises(ValueError):
            book_service.update_availability("B999", False)

    def test_delete_book(self):
        book_service.add_book("B001", "Python Programming", "John Smith", "Programming")
        book_service.delete_book("B001")
        self.assertIsNone(book_service.get_book("B001"))

    def test_delete_nonexistent_book_raises(self):
        with self.assertRaises(ValueError):
            book_service.delete_book("B999")


if __name__ == "__main__":
    unittest.main()
