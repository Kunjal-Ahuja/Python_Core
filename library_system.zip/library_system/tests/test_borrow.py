"""test_borrow.py - Validates borrow/return transactions."""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data.datastore import datastore
from services import member_service, book_service, borrow_service


class BorrowServiceTestCase(unittest.TestCase):
    def setUp(self):
        datastore.reset()
        member_service.add_member("M001", "Ravi", 28, "premium")
        book_service.add_book("B001", "Python Programming", "John Smith", "Programming")

    def test_create_borrow_record(self):
        record = borrow_service.create_borrow_record("BR001", "M001", "B001", "2026-07-01")
        self.assertEqual(record.member_id, "M001")
        self.assertEqual(record.book_id, "B001")
        self.assertFalse(record.is_returned())

        # Book should now be marked unavailable
        book = book_service.get_book("B001")
        self.assertFalse(book.is_available)

    def test_borrow_nonexistent_member_raises(self):
        with self.assertRaises(ValueError):
            borrow_service.create_borrow_record("BR001", "M999", "B001")

    def test_borrow_nonexistent_book_raises(self):
        with self.assertRaises(ValueError):
            borrow_service.create_borrow_record("BR001", "M001", "B999")

    def test_borrow_unavailable_book_raises(self):
        borrow_service.create_borrow_record("BR001", "M001", "B001", "2026-07-01")
        with self.assertRaises(ValueError):
            borrow_service.create_borrow_record("BR002", "M001", "B001", "2026-07-02")

    def test_mark_return(self):
        borrow_service.create_borrow_record("BR001", "M001", "B001", "2026-07-01")
        record = borrow_service.mark_return("BR001", "2026-07-10")
        self.assertTrue(record.is_returned())
        self.assertEqual(record.return_date, "2026-07-10")

        # Book should be available again
        book = book_service.get_book("B001")
        self.assertTrue(book.is_available)

    def test_mark_return_already_returned_raises(self):
        borrow_service.create_borrow_record("BR001", "M001", "B001", "2026-07-01")
        borrow_service.mark_return("BR001", "2026-07-10")
        with self.assertRaises(ValueError):
            borrow_service.mark_return("BR001", "2026-07-11")

    def test_mark_return_nonexistent_record_raises(self):
        with self.assertRaises(ValueError):
            borrow_service.mark_return("BR999")

    def test_get_all_borrow_records(self):
        borrow_service.create_borrow_record("BR001", "M001", "B001", "2026-07-01")
        records = borrow_service.get_all_borrow_records()
        self.assertEqual(len(records), 1)

    def test_delete_borrow_record(self):
        borrow_service.create_borrow_record("BR001", "M001", "B001", "2026-07-01")
        borrow_service.delete_borrow_record("BR001")
        self.assertIsNone(borrow_service.get_borrow_record("BR001"))

    def test_delete_nonexistent_borrow_record_raises(self):
        with self.assertRaises(ValueError):
            borrow_service.delete_borrow_record("BR999")


if __name__ == "__main__":
    unittest.main()
