"""test_member.py - Validates member CRUD operations."""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data.datastore import datastore
from services import member_service


class MemberServiceTestCase(unittest.TestCase):
    def setUp(self):
        datastore.reset()

    def test_add_member(self):
        member = member_service.add_member("M001", "Ravi", 28, "premium")
        self.assertEqual(member.id, "M001")
        self.assertIn("M001", datastore.members)

    def test_add_duplicate_member_raises(self):
        member_service.add_member("M001", "Ravi", 28)
        with self.assertRaises(ValueError):
            member_service.add_member("M001", "Someone Else", 30)

    def test_add_member_invalid_membership_type_raises(self):
        with self.assertRaises(ValueError):
            member_service.add_member("M002", "Anu", 22, "gold")

    def test_get_member(self):
        member_service.add_member("M001", "Ravi", 28)
        member = member_service.get_member("M001")
        self.assertIsNotNone(member)
        self.assertEqual(member.name, "Ravi")

    def test_get_all_members(self):
        member_service.add_member("M001", "Ravi", 28)
        member_service.add_member("M002", "Anu", 22)
        members = member_service.get_all_members()
        self.assertEqual(len(members), 2)

    def test_update_membership(self):
        member_service.add_member("M001", "Ravi", 28, "regular")
        updated = member_service.update_membership("M001", "premium")
        self.assertEqual(updated.membership_type, "premium")

    def test_update_membership_nonexistent_member_raises(self):
        with self.assertRaises(ValueError):
            member_service.update_membership("M999", "premium")

    def test_delete_member(self):
        member_service.add_member("M001", "Ravi", 28)
        member_service.delete_member("M001")
        self.assertIsNone(member_service.get_member("M001"))

    def test_delete_nonexistent_member_raises(self):
        with self.assertRaises(ValueError):
            member_service.delete_member("M999")


if __name__ == "__main__":
    unittest.main()
