"""
member_service.py
--------------------
CRUD operations for Member records, backed by the dictionary datastore.
"""

from models.member import Member
from data.datastore import datastore
from utils.validator import is_valid_membership_type, is_valid_age, is_non_empty_string


def add_member(member_id, name, age, membership_type="regular"):
    """
    Create and store a new Member.

    Raises:
        ValueError: if the member_id already exists, or if inputs are invalid.
    """
    if member_id in datastore.members:
        raise ValueError(f"Member ID '{member_id}' already exists.")
    if not is_non_empty_string(name):
        raise ValueError("Member name must be a non-empty string.")
    if not is_valid_age(age):
        raise ValueError("Member age must be a non-negative integer.")
    if not is_valid_membership_type(membership_type):
        raise ValueError(
            f"Invalid membership type '{membership_type}'. "
            f"Must be one of: regular, premium."
        )

    member = Member(member_id, name, age, membership_type)
    datastore.members[member_id] = member
    return member


def get_member(member_id):
    """Return the Member with the given ID, or None if not found."""
    return datastore.members.get(member_id)


def get_all_members():
    """Return a list of all Member records."""
    return list(datastore.members.values())


def update_membership(member_id, new_membership_type):
    """
    Update a member's membership type.

    Raises:
        ValueError: if the member doesn't exist or the type is invalid.
    """
    member = datastore.members.get(member_id)
    if member is None:
        raise ValueError(f"Member ID '{member_id}' not found.")
    if not is_valid_membership_type(new_membership_type):
        raise ValueError(f"Invalid membership type '{new_membership_type}'.")

    member.membership_type = new_membership_type
    return member


def delete_member(member_id):
    """
    Delete a member from the datastore.

    Raises:
        ValueError: if the member doesn't exist.
    """
    if member_id not in datastore.members:
        raise ValueError(f"Member ID '{member_id}' not found.")
    del datastore.members[member_id]
