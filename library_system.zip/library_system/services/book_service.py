"""
book_service.py
------------------
CRUD operations for Book records, backed by the dictionary datastore.
"""

from models.book import Book
from data.datastore import datastore
from utils.validator import is_non_empty_string


def add_book(book_id, title, author, genre, is_available=True):
    """
    Create and store a new Book.

    Raises:
        ValueError: if the book_id already exists, or inputs are invalid.
    """
    if book_id in datastore.books:
        raise ValueError(f"Book ID '{book_id}' already exists.")
    if not is_non_empty_string(title):
        raise ValueError("Book title must be a non-empty string.")
    if not is_non_empty_string(author):
        raise ValueError("Book author must be a non-empty string.")

    book = Book(book_id, title, author, genre, is_available)
    datastore.books[book_id] = book
    return book


def get_book(book_id):
    """Return the Book with the given ID, or None if not found."""
    return datastore.books.get(book_id)


def get_all_books():
    """Return a list of all Book records."""
    return list(datastore.books.values())


def update_availability(book_id, is_available):
    """
    Update a book's availability status.

    Raises:
        ValueError: if the book doesn't exist.
    """
    book = datastore.books.get(book_id)
    if book is None:
        raise ValueError(f"Book ID '{book_id}' not found.")

    book.is_available = is_available
    return book


def delete_book(book_id):
    """
    Delete a book from the datastore.

    Raises:
        ValueError: if the book doesn't exist.
    """
    if book_id not in datastore.books:
        raise ValueError(f"Book ID '{book_id}' not found.")
    del datastore.books[book_id]
