"""
library_system.py
--------------------
Orchestrator that ties all services (member, book, borrow) together,
providing a single, simple interface for the rest of the application
(e.g. main.py) to use.
"""

from services import member_service, book_service, borrow_service


class LibrarySystem:
    """A single facade over the member, book, and borrow services."""

    # -- Members --------------------------------------------------------
    def add_member(self, member_id, name, age, membership_type="regular"):
        return member_service.add_member(member_id, name, age, membership_type)

    def get_member(self, member_id):
        return member_service.get_member(member_id)

    def get_all_members(self):
        return member_service.get_all_members()

    def update_membership(self, member_id, new_membership_type):
        return member_service.update_membership(member_id, new_membership_type)

    def delete_member(self, member_id):
        return member_service.delete_member(member_id)

    # -- Books ------------------------------------------------------------
    def add_book(self, book_id, title, author, genre, is_available=True):
        return book_service.add_book(book_id, title, author, genre, is_available)

    def get_book(self, book_id):
        return book_service.get_book(book_id)

    def get_all_books(self):
        return book_service.get_all_books()

    def update_availability(self, book_id, is_available):
        return book_service.update_availability(book_id, is_available)

    def delete_book(self, book_id):
        return book_service.delete_book(book_id)

    # -- Borrow / Return ---------------------------------------------------
    def borrow_book(self, borrow_id, member_id, book_id, borrow_date=None):
        return borrow_service.create_borrow_record(
            borrow_id, member_id, book_id, borrow_date
        )

    def return_book(self, borrow_id, return_date=None):
        return borrow_service.mark_return(borrow_id, return_date)

    def get_borrow_record(self, borrow_id):
        return borrow_service.get_borrow_record(borrow_id)

    def get_all_borrow_records(self):
        return borrow_service.get_all_borrow_records()

    def delete_borrow_record(self, borrow_id):
        return borrow_service.delete_borrow_record(borrow_id)
