"""
borrow_service.py
--------------------
Handles borrow transactions: creating a borrow record, marking a book as
returned, and deleting a borrow record. Backed by the dictionary
datastore.
"""

from datetime import date

from models.borrow_record import BorrowRecord
from data.datastore import datastore
from utils.validator import is_book_available


def create_borrow_record(borrow_id, member_id, book_id, borrow_date=None):
    """
    Create a new borrow record linking a member and a book.

    Raises:
        ValueError: if the borrow_id already exists, the member/book
                    doesn't exist, or the book is not available.
    """
    if borrow_id in datastore.borrows:
        raise ValueError(f"Borrow ID '{borrow_id}' already exists.")

    member = datastore.members.get(member_id)
    if member is None:
        raise ValueError(f"Member ID '{member_id}' not found.")

    book = datastore.books.get(book_id)
    if book is None:
        raise ValueError(f"Book ID '{book_id}' not found.")

    if not is_book_available(book):
        raise ValueError(f"Book '{book.title}' is not available for borrowing.")

    if borrow_date is None:
        borrow_date = date.today().isoformat()

    record = BorrowRecord(borrow_id, member_id, book_id, borrow_date)
    datastore.borrows[borrow_id] = record

    book.mark_borrowed()
    return record


def mark_return(borrow_id, return_date=None):
    """
    Mark a borrow record as returned and make the book available again.

    Raises:
        ValueError: if the borrow record doesn't exist, or the book has
                    already been returned.
    """
    record = datastore.borrows.get(borrow_id)
    if record is None:
        raise ValueError(f"Borrow record '{borrow_id}' not found.")
    if record.is_returned():
        raise ValueError(f"Borrow record '{borrow_id}' is already marked as returned.")

    if return_date is None:
        return_date = date.today().isoformat()

    record.mark_returned(return_date)

    book = datastore.books.get(record.book_id)
    if book is not None:
        book.mark_returned()

    return record


def get_borrow_record(borrow_id):
    """Return the BorrowRecord with the given ID, or None if not found."""
    return datastore.borrows.get(borrow_id)


def get_all_borrow_records():
    """Return a list of all BorrowRecord entries."""
    return list(datastore.borrows.values())


def delete_borrow_record(borrow_id):
    """
    Delete a borrow record from the datastore.

    Raises:
        ValueError: if the borrow record doesn't exist.
    """
    if borrow_id not in datastore.borrows:
        raise ValueError(f"Borrow record '{borrow_id}' not found.")
    del datastore.borrows[borrow_id]
