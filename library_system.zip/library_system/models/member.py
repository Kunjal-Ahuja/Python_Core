"""member.py - Member model. Extends Person, adds membership info."""

from models.person import Person


class Member(Person):
    """Represents a library member. Inherits shared attributes from Person
    and adds a membership_type (e.g., 'regular', 'premium')."""

    def __init__(self, member_id, name, age, membership_type="regular"):
        super().__init__(member_id, name, age)
        self.membership_type = membership_type

    def __str__(self):
        return (
            f"{super().__str__()}, "
            f"Membership: {self.membership_type}"
        )
