"""borrow_record.py - Associates a Member with a Book, recording the
borrow_date and return_date."""


class BorrowRecord:
    """Represents a single borrow transaction linking a member and a book."""

    def __init__(self, borrow_id, member_id, book_id, borrow_date, return_date=None):
        self.id = borrow_id
        self.member_id = member_id
        self.book_id = book_id
        self.borrow_date = borrow_date
        self.return_date = return_date

    def is_returned(self):
        """Return True if this borrow record has a recorded return date."""
        return self.return_date is not None

    def mark_returned(self, return_date):
        """Record the date this book was returned."""
        self.return_date = return_date

    def __str__(self):
        status = f"Returned on {self.return_date}" if self.is_returned() else "Not returned yet"
        return (
            f"Borrow ID: {self.id}, Member ID: {self.member_id}, "
            f"Book ID: {self.book_id}, Borrowed on: {self.borrow_date}, {status}"
        )
