"""book.py - Book model representing a book in the library."""


class Book:
    """Represents a book (id, title, author, genre, is_available)."""

    def __init__(self, book_id, title, author, genre, is_available=True):
        self.id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.is_available = is_available

    def mark_borrowed(self):
        """Mark this book as currently borrowed (unavailable)."""
        self.is_available = False

    def mark_returned(self):
        """Mark this book as returned (available again)."""
        self.is_available = True

    def __str__(self):
        status = "Available" if self.is_available else "Borrowed"
        return (
            f"ID: {self.id}, Title: {self.title}, Author: {self.author}, "
            f"Genre: {self.genre}, Status: {status}"
        )
