# Library Management System (OOP Case Study)

A structured Python application managing books, members, and borrow
records using OOP concepts, CRUD operations, and a dictionary datastore
to simulate a database.

## Overview

- **Books** — title, author, genre, availability status
- **Members** — id, name, age, membership type
- **Borrow Records** — which member borrowed which book, borrow date, return date

## Project Structure

```
library_system/
│
├── models/                  # Core domain models
│   ├── person.py            # Base class for shared attributes
│   ├── member.py             # Extends Person, adds membership info
│   ├── book.py                # Represents books in the library
│   └── borrow_record.py       # Links member and book borrowing
│
├── services/                 # Business logic for each model
│   ├── member_service.py      # CRUD for members
│   ├── book_service.py         # CRUD for books
│   ├── borrow_service.py       # Borrow/return transactions
│   └── library_system.py       # Orchestrator tying services together
│
├── data/
│   └── datastore.py            # Dictionary datastore (mini database)
│
├── tests/                     # Unit tests for CRUD operations
│   ├── test_member.py
│   ├── test_book.py
│   └── test_borrow.py
│
├── utils/
│   └── validator.py            # Validation helpers
│
├── main.py                    # Entry point to run the system
└── README.md
```

## OOP Concepts Demonstrated

- **Inheritance**: `Member` extends `Person`, inheriting `id`, `name`, `age`
  and adding `membership_type`.
- **Encapsulation**: Each model manages its own state; services provide
  the only sanctioned way to mutate the datastore.
- **Single Responsibility**: Each service handles CRUD for exactly one
  model; `library_system.py` acts purely as an orchestrating facade.

## Dictionary Datastore

`data/datastore.py` exposes a shared `datastore` instance structured as:

```python
{
    "members": {},   # member_id -> Member
    "books": {},      # book_id -> Book
    "borrows": {}     # borrow_id -> BorrowRecord
}
```

All services read from and write to this same in-memory store, so data
persists for the life of the running process (it is not saved to disk).

## How to Run

From the parent directory of `library_system/`:

```bash
python3 library_system/main.py
```

This demonstrates the full workflow:
1. Add a member
2. Add books to the library
3. Create a borrow record linking member and book
4. Return the book
5. Print all records to confirm

## Running Tests

From the parent directory of `library_system/`:

```bash
python3 -m unittest library_system.tests.test_member -v
python3 -m unittest library_system.tests.test_book -v
python3 -m unittest library_system.tests.test_borrow -v
```

Or run all three at once:

```bash
python3 -m unittest library_system.tests.test_member library_system.tests.test_book library_system.tests.test_borrow -v
```

Each test calls `datastore.reset()` in `setUp()` so tests never interfere
with one another.
