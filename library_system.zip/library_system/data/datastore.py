"""
datastore.py - Dictionary acting as a mini database.

Structure:
    {
        "members": {member_id: Member},
        "books": {book_id: Book},
        "borrows": {borrow_id: BorrowRecord}
    }

A single shared DataStore instance is exposed as `datastore` so all
services operate on the same in-memory data.
"""


class DataStore:
    """A simple in-memory 'database' backed by dictionaries."""

    def __init__(self):
        self.members = {}   # member_id -> Member
        self.books = {}      # book_id -> Book
        self.borrows = {}    # borrow_id -> BorrowRecord

    def reset(self):
        """Clear all stored data. Useful for tests."""
        self.members = {}
        self.books = {}
        self.borrows = {}

    def as_dict(self):
        """Return the datastore's contents as a plain dict (for inspection)."""
        return {
            "members": self.members,
            "books": self.books,
            "borrows": self.borrows,
        }


# Shared singleton instance used across the whole application
datastore = DataStore()
