"""
main.py
--------
Entry point of the Library Management System application.

Demonstrates the workflow:
    1. Add a member
    2. Add books to the library
    3. Create a borrow record linking member and book
    4. Print details to confirm
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from services.library_system import LibrarySystem


def main():
    library = LibrarySystem()

    # 1. Add a member
    member = library.add_member("M001", "Ravi Kumar", 28, "premium")
    print("Member added:")
    print(member)

    # 2. Add books to the library
    book1 = library.add_book("B001", "Python Programming", "John Smith", "Programming")
    book2 = library.add_book("B002", "The Hobbit", "J.R.R. Tolkien", "Fantasy")
    print("\nBooks added:")
    print(book1)
    print(book2)

    # 3. Create a borrow record linking member and book
    record = library.borrow_book("BR001", "M001", "B001")
    print("\nBorrow record created:")
    print(record)

    # 4. Print details to confirm
    print("\nBook status after borrowing:")
    print(library.get_book("B001"))

    print("\nReturning the book...")
    library.return_book("BR001")
    print("Borrow record after return:")
    print(library.get_borrow_record("BR001"))

    print("\nBook status after return:")
    print(library.get_book("B001"))

    print("\nAll members:")
    for m in library.get_all_members():
        print(m)

    print("\nAll books:")
    for b in library.get_all_books():
        print(b)

    print("\nAll borrow records:")
    for r in library.get_all_borrow_records():
        print(r)


if __name__ == "__main__":
    main()
